import pygame
import random

pygame.init()

scale_personaje = 1.0
scale_enemigo = 1.7

paisaje = pygame.image.load("assets/image/paisaje/paisaje1.png")
paisaje = pygame.transform.scale(paisaje, (1000, 600))

img_ataque = pygame.image.load("assets/image/weapons/energy_ball.0.png")
img_ataque = pygame.transform.scale(img_ataque, (100, 50))  

def escalar_img(image, scale):
    w = image.get_width()
    h = image.get_height()
    nueva_imagen = pygame.transform.scale(image, (int(w * scale), int(h * scale)))
    return nueva_imagen

animacion = []
for i in range(7):
    img = pygame.image.load(f"assets/image/character/player/player_{i}.PNG")
    img = escalar_img(img, scale_personaje)
    animacion.append(img)
    
animacion_enemigo = []
for i in range(8):
    img_enemigo = pygame.image.load(f"assets/image/character/enemigo/enemigo.{i}.PNG")
    img_enemigo = escalar_img(img_enemigo, scale_enemigo)
    animacion_enemigo.append(img_enemigo)

width = 1000
height = 600
height_1= 100
screen = pygame.display.set_mode((width, height))
pygame.display.set_caption("rosendo")
FPS = 80
velocidad = 5

blanco = (255, 255, 255)
negro = (0, 0, 0)
gris = (200, 200, 200)
verde = (0, 255, 0)
rojo = (255, 0, 0)

mover_izquierda = False
mover_derecha = False

gravedad = 0.5
velocidad_salto = -15

class Player:
    def __init__(self, x, y, animacion):
        self.flip = False
        self.animacion = animacion
        self.frame_index = 0
        self.update_time = pygame.time.get_ticks()
        self.image = animacion[self.frame_index]
        self.rect = self.image.get_rect()
        self.shape = pygame.Rect(0, 0, 20, 20)
        self.shape.center = (x, y)
        self.en_suelo = True
        self.saltar = False
        self.velocidad_y = 0

    def movimiento(self, delta_x):
        if delta_x < 0:
            self.flip = True
        if delta_x > 0:
            self.flip = False    
        self.shape.x += delta_x

    def update(self):
        cooldown_animacion = 100
        self.image = self.animacion[self.frame_index]  
        if pygame.time.get_ticks() - self.update_time >= cooldown_animacion:
            self.frame_index += 1
            self.update_time = pygame.time.get_ticks()
            if self.frame_index >= len(self.animacion):
                self.frame_index = 0

        if self.saltar and self.en_suelo:
            self.velocidad_y = velocidad_salto
            self.en_suelo = False
            self.saltar = False

        self.velocidad_y += gravedad
        self.shape.y += self.velocidad_y

        if self.shape.bottom >= height - 100:
            self.shape.bottom = height - 100
            self.en_suelo = True
            self.velocidad_y = 0

    def draw(self, interfaz):
        image_flip = pygame.transform.flip(self.image, self.flip, False)
        interfaz.blit(image_flip, self.shape)

class Enemigos():
    def __init__(self, x, y, animacion_enemigo, player):
        self.animacion = animacion_enemigo
        self.frame_index = 0
        self.update_time = pygame.time.get_ticks()

        self.image = pygame.transform.flip(animacion_enemigo[self.frame_index], True, False)

        self.rect = self.image.get_rect()

        self.rect.x = player.shape.x + 100
        self.rect.y = player.shape.y -120

        self.velocidad_x = -3

    def update(self):
        self.rect.x += self.velocidad_x

        if self.rect.right < 0:
            self.rect.x = width

        cooldown_animacion = 100
        self.image = self.animacion[self.frame_index]
        if pygame.time.get_ticks() - self.update_time >= cooldown_animacion:
            self.frame_index += 1
            self.update_time = pygame.time.get_ticks()
            if self.frame_index >= len(self.animacion):
                self.frame_index = 0

        self.image = pygame.transform.flip(self.animacion[self.frame_index], True, False)

    def draw(self, interfaz):
        interfaz.blit(self.image, self.rect)
    
   


class Ataque():  
    def __init__(self, x, y):
        self.image = img_ataque
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.velocidad_x = 10 

    def update(self):
        self.rect.x += self.velocidad_x  
        if self.rect.x > width:  
            return True
        return False

    def draw(self, interfaz):
        interfaz.blit(self.image, self.rect)

player = Player(0, height - 100, animacion)

enemigo = Enemigos(1000, 100, animacion_enemigo, player)

ataques = []  

sprite = pygame.sprite.Group()
sprite.add_internal(player)
sprite.add_internal(enemigo)

reloj = pygame.time.Clock()

x = 0

run = True
while run:
    reloj.tick(FPS)

    delta_x = 0

    if mover_derecha:
        delta_x = velocidad
    if mover_izquierda:
        delta_x = -velocidad

    player.movimiento(delta_x)
    player.update()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
        
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_a:
                mover_izquierda = True
            if event.key == pygame.K_d:
                mover_derecha = True
            if event.key == pygame.K_SPACE and player.en_suelo:
                player.saltar = True
            if event.key == pygame.K_f: 
                ataques.append(Ataque(player.shape.x + 30, player.shape.y)) 

        if event.type == pygame.KEYUP:
            if event.key == pygame.K_a:
                mover_izquierda = False
            if event.key == pygame.K_d:
                mover_derecha = False
            if event.key == pygame.K_SPACE:
                player.saltar = False

    
    for ataque in ataques[:]:  
        if ataque.update():  
            ataques.remove(ataque)   
        
            
        if ataque.rect.colliderect(enemigo.rect):
            ataques.remove(ataque)  # Eliminar el ataque al impactar
            enemigo.rect.x = width   # Mover al enemigo a la derecha (off-screen)
            enemigo.rect.y = player.shape.y -120
            
        if enemigo.rect.colliderect(player.rect):
           enemigo.remove(player)
           pygame.quit
           

    x_relativa = x % screen.get_rect().width
    screen.blit(paisaje, [x_relativa - screen.get_rect().width, 0])
    if x_relativa < width:
        screen.blit(paisaje, (x_relativa, 0))
    x -= 1

    player.draw(screen)
    enemigo.update()
    enemigo.draw(screen)

    # Dibujar los ataques
    for ataque in ataques:
        ataque.draw(screen)

    pygame.display.flip()

pygame.quit()

